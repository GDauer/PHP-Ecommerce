create
  definer = root@localhost procedure sp_userspasswordsrecoveries_create(IN piduser int, IN pdesip varchar(45))
BEGIN

  INSERT INTO tb_userspasswordsrecoveries (iduser, desip)
  VALUES(piduser, pdesip);

  SELECT * FROM tb_userspasswordsrecoveries
  WHERE idrecovery = LAST_INSERT_ID();

END;

